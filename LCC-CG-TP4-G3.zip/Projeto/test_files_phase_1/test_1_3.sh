../bin/generator sphere 1 10 10 sphere.3d
../bin/engine test_1_3.xml
rm sphere.3d