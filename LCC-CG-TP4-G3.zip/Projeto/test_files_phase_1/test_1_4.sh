../bin/generator box 2 3 box.3d
../bin/engine test_1_4.xml
rm box.3d