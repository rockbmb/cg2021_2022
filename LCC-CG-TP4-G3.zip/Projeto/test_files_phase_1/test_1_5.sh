../bin/generator plane 10 3 plane.3d
../bin/generator sphere 1 10 10 sphere.3d
../bin/engine test_1_5.xml
rm plane.3d sphere.3d