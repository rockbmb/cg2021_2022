./cmake-build-debug/generator cone 1 2 4 3 cone.3d
./cmake-build-debug/engine test_files_phase1/test_1_1.xml

./cmake-build-debug/generator cone 1 2 4 3 cone.3d
./cmake-build-debug/engine test_files_phase1/test_1_2.xml

./cmake-build-debug/generator sphere 1 10 10 sphere.3d
./cmake-build-debug/engine test_files_phase1/test_1_3.xml

./cmake-build-debug/generator box 2 3 box.3d
./cmake-build-debug/engine test_files_phase1/test_1_4.xml

./cmake-build-debug/generator plane 10 3 plane.3d
./cmake-build-debug/generator sphere 1 10 10 sphere.3d
./cmake-build-debug/engine test_files_phase1/test_1_5.xml