../bin/generator cone 2 4 4 3 cone.3d
../bin/engine test_1_2.xml
rm cone.3d