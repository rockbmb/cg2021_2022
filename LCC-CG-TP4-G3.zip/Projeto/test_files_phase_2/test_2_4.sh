../bin/generator box 2 3 box.3d
../bin/engine test_2_4.xml
rm box.3d