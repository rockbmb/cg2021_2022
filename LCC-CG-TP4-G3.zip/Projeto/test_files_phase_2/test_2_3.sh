../bin/generator box 2 3 box.3d
../bin/generator sphere 1 8 8 sphere.3d
../bin/generator cone 1 2 4 3 cone.3d
../bin/engine test_2_3.xml
rm box.3d cone.3d sphere.3d